package main

import "golandproject/Router"

func main() {
	Router.InitRouter()
}
